#include <cstdio>
#include <filesystem>
#include <windows.h>

int main()
{
	SetConsoleTitleW(L"WarPrime Setup");
	printf("WarPrime Bootstrapper Setup\n\n");

	if (std::filesystem::exists("Warframe.x64.exe"))
	{
		{
			std::error_code ec;
			std::filesystem::create_directory("WarPrime", ec);
		}

		printf("Downloading WarPrime installer script...\n");
		system(R"(powershell -Command "try { Invoke-WebRequest -UseBasicParsing 'https://raw.githubusercontent.com/kekyoko/warprime/main/scripts/Download-Latest-DLL.ps1' -OutFile 'WarPrime/Download Latest DLL.ps1' } catch { Write-Host 'Failed to download the WarPrime installer script.' }")");

		if (!std::filesystem::exists("WarPrime/Download Latest DLL.ps1"))
		{
			printf("Could not download the WarPrime installer script. Please check your internet connection.\n");
			system("pause > nul");
			return 1;
		}

		system(R"(cd WarPrime && powershell -executionpolicy bypass -File "Download Latest DLL.ps1")");
	}
	else
	{
		printf("Please put this program into your Warframe installation folder (the one where Warframe.x64.exe is in) before running it.\n");
		system("pause > nul");
	}

	return 0;
}
